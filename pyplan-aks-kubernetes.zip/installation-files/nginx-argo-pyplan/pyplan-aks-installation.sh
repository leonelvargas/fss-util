#!/bin/bash

#Bastion Configuration
sudo apt update -y
sudo apt upgrade -y
#AZ CLI
sudo curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
#Helm CLI
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
#Argo CD
wget https://github.com/argoproj/argo-cd/releases/latest/download/argocd-linux-amd64
sudo mv argocd* /usr/local/bin/argocd
sudo chmod +x /usr/local/bin/argocd
#Utils
sudo apt install -y net-tools acl unzip
#Kubectl CLI
sudo curl -LO https://storage.googleapis.com/kubernetes-release/release/v1.23.6/bin/linux/amd64/kubectl
sudo mv ./kubectl /usr/local/bin/kubectl
sudo chmod +x /usr/local/bin/kubectl

#Update the helm repos
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo add argo https://argoproj.github.io/argo-helm
helm repo update

#Install Nginx Ingress Controller
kubectl create ns ingress & \
helm upgrade pyplan30-helm ingress-nginx/ingress-nginx \
--namespace ingress \
--install --wait \
--version 4.1.4 \
--set controller.replicaCount=1 \
--set controller.nodeSelector."env=Pyplan" \
--set controller.service.annotations."service\.beta\.kubernetes\.io/azure-load-balancer-health-probe-request-path"=/healthz \
--set controller.nodeSelector."beta\.kubernetes\.io/os"=linux \
--set defaultBackend.nodeSelector."beta\.kubernetes\.io/os"=linux \
--set controller.admissionWebhooks.patch.nodeSelector."beta\.kubernetes\.io/os"=linux

#Install ArgoCD - PyplanProject
kubectl create ns argo-cd & \
helm upgrade pyplan30-env argo/argo-cd \
-f /pyplan/deploy/argo-cd/argo-values.yaml \
--namespace argo-cd \
--version 4.8.3 \
--install --wait
kubectl apply -f /pyplan/deploy/home/vsts/work/_temp/private-repo-key.yaml
kubectl apply -f /pyplan/deploy/argo-cd/pyplan-app.yaml

#Install Pyplan-svc
kubectl create ns pyplan

kubectl create secret tls -n argo-cd argocd-server-tls \
--cert cert/cert.pem \
--key cert/cert.key

kubectl create secret tls -n pyplan pyplan-tls-secret \
--cert cert/cert.pem \
--key cert/cert.key

kubectl create secret generic -n pyplan postgres-credentials \
--from-literal=PGDATABASE=pyplan_db \
--from-literal=PGUSER=pyplanadm@pyplantestepg \
--from-literal=PGPASSWORD=Pyplan1234 \
--from-literal=PGHOST=pyplantestepg.postgres.database.azure.com \
--from-literal=PGPORT="5432"

echo "Argo-CD UI password"
kubectl -n argo-cd get secret argocd-initial-admin-secret \
-o jsonpath="{.data.password}" | base64 -d; echo

echo "Load Balancer Public DNS"
kubectl --namespace ingress get services -o wide pyplan30-helm-ingress-nginx-controller

